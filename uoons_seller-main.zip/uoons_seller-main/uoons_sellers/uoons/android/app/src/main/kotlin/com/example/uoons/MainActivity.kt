package com.example.uoons

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
